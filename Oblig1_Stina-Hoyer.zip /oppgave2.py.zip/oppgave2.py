fornavn = "Stina"
Etternavn = "Hoyer"
Alder = "18"
print("Hei, jeg heter (fornavn) (Etternavn) og er (Alder) år gammel")
